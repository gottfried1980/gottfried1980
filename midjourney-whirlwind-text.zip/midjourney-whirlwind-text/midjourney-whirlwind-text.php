<?php
/*
Plugin Name: Midjourney Whirlwind Text
Plugin URI: https://www.gancpt.at
Description: A sophisticated whirlwind text effect plugin inspired by Midjourney, using GSAP for 3D animations.
Version: 7.4
Author: Gottfried Aumann
Author URI: https://www.gancpt.at
License: GPL2
*/

// Enqueue GSAP and CSS for 3D effects
function midjourney_whirlwind_text_enqueue_scripts() {
    wp_enqueue_script('gsap-core', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.11.3/gsap.min.js', [], null, true);
    wp_enqueue_style('whirlwind-style', plugins_url('whirlwind-style.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'midjourney_whirlwind_text_enqueue_scripts');
add_action('admin_enqueue_scripts', 'midjourney_whirlwind_text_enqueue_scripts');

// Add an admin menu item
function midjourney_whirlwind_text_admin_menu() {
    add_menu_page(
        'Whirlwind Text', // Page title
        'Whirlwind Text', // Menu title
        'manage_options', // Capability
        'midjourney-whirlwind-text', // Menu slug
        'midjourney_whirlwind_text_admin_page', // Callback function
        'dashicons-art', // Icon
        110 // Position
    );
}
add_action('admin_menu', 'midjourney_whirlwind_text_admin_menu');

// Admin page content
function midjourney_whirlwind_text_admin_page() {
    ?>
    <div class="wrap">
        <h1>Whirlwind Text</h1>
        <form id="whirlwind-text-form">
            <h2>Enter Text for the Whirlwind</h2>
            <textarea id="whirlwind-text" rows="5" style="width: 100%;"></textarea>
            <p class="submit">
                <button type="button" id="whirlwind-preview-button" class="button button-primary">Preview Whirlwind</button>
            </p>
        </form>
        <h2>Whirlwind Preview</h2>
        <div id="whirlwind-preview-container" style="height: 500px; background: #f9f9f9; overflow: hidden; position: relative; perspective: 2000px;">
            <div id="whirlwind-preview" style="padding: 20px; position: relative; width: 100%; height: 100%; display: flex; justify-content: center; align-items: center;">
                <!-- Whirlwind text will be inserted here -->
            </div>
        </div>
    </div>
    <script type="text/javascript">
    document.addEventListener("DOMContentLoaded", function() {
        var previewButton = document.getElementById('whirlwind-preview-button');
        var animations = [];
        var previewContainer = document.getElementById('whirlwind-preview');

        function startWhirlwindTextAnimation(container, text) {
            container.innerHTML = '';

            if (typeof gsap === 'undefined') {
                console.error('GSAP is not loaded.');
                return;
            }

            var words = text.split(' ');
            var radius = 200; // Base radius of the whirlwind
            var depth = 800; // Depth for the 3D effect
            var layers = 10; // Number of layers in the whirlwind
            var newAnimations = []; // Store all animations to clean them up later

            words.forEach(function(word, index) {
                var wordSpan = document.createElement('span');
                wordSpan.textContent = word;
                wordSpan.className = 'whirlwind-word';
                wordSpan.style.position = 'absolute';
                wordSpan.style.fontSize = '1.2em'; // Larger text
                wordSpan.style.whiteSpace = 'nowrap';
                container.appendChild(wordSpan);

                var layer = index % layers;
                var angle = (360 / layers) * layer;
                var x = radius * Math.cos(angle * (Math.PI / 180));
                var y = radius * Math.sin(angle * (Math.PI / 180));
                var z = (index * depth) / words.length;

                gsap.set(wordSpan, {
                    x: x,
                    y: y,
                    z: z
                });

                var rotationAnim = gsap.to(wordSpan, {
                    rotationY: "+=360",
                    rotationX: "+=360",
                    z: gsap.utils.random(-depth, depth),
                    duration: gsap.utils.random(10, 15),
                    repeat: -1,
                    ease: "linear"
                });

                var movementAnim = gsap.to(wordSpan, {
                    x: `+=${gsap.utils.random(-50, 50)}`,
                    y: `+=${gsap.utils.random(-50, 50)}`,
                    z: `+=${gsap.utils.random(-200, 200)}`,
                    scale: gsap.utils.random(0.5, 1.5),
                    duration: gsap.utils.random(5, 10),
                    repeat: -1,
                    yoyo: true,
                    ease: "power1.inOut"
                });

                newAnimations.push(rotationAnim, movementAnim); // Store animations
            });

            return newAnimations; // Return animations for cleanup
        }

        previewButton.addEventListener('click', function() {
            var text = document.getElementById('whirlwind-text').value;

            // Cleanup previous animations
            animations.forEach(function(anim) {
                anim.kill();
            });
            animations = [];

            if (text.trim() !== '') {
                animations = startWhirlwindTextAnimation(previewContainer, text);
            }
        });

        // Optional: Cleanup when leaving the page
        window.addEventListener('beforeunload', function() {
            animations.forEach(function(anim) {
                anim.kill();
            });
        });
    });
    </script>
    <?php
}

// Shortcode for whirlwind text in blog articles
function midjourney_whirlwind_text_shortcode($atts, $content = null) {
    $output = '<div class="whirlwind-text-container" style="position: relative; height: 300px; overflow: hidden; display: flex; justify-content: center; align-items: center; perspective: 2000px;">';

    // Create spans for each word
    $output .= '<div id="whirlwind-text-shortcode">';
    $words = explode(' ', $content);
    foreach ($words as $index => $word) {
        $output .= '<span class="whirlwind-word" style="position: absolute; font-size: 1.2em; white-space: nowrap;">' . $word . '</span>';
    }
    $output .= '</div>';

    $output .= '</div>';
    $output .= '
    <script type="text/javascript">
    document.addEventListener("DOMContentLoaded", function() {
        function startWhirlwindTextAnimation() {
            if (typeof gsap !== "undefined") {
                var words = document.querySelectorAll(".whirlwind-word");
                var radius = 200; // Base radius of the whirlwind
                var depth = 800; // Depth for the 3D effect
                var layers = 10; // Number of layers in the whirlwind
                var animations = [];

                words.forEach(function(word, index) {
                    var layer = index % layers;
                    var angle = (360 / layers) * layer;
                    var x = radius * Math.cos(angle * (Math.PI / 180));
                    var y = radius * Math.sin(angle * (Math.PI / 180));
                    var z = (index * depth) / words.length;

                    gsap.set(word, {
                        x: x,
                        y: y,
                        z: z
                    });

                    var rotationAnim = gsap.to(word, {
                        rotationY: "+=360",
                        rotationX: "+=360",
                        z: gsap.utils.random(-depth, depth),
                        duration: gsap.utils.random(10, 15),
                        repeat: -1,
                        ease: "linear"
                    });

                    var movementAnim = gsap.to(word, {
                        x: `+=${gsap.utils.random(-50, 50)}`,
                        y: `+=${gsap.utils.random(-50, 50)}`,
                        z: `+=${gsap.utils.random(-200, 200)}`,
                        scale: gsap.utils.random(0.5, 1.5),
                        duration: gsap.utils.random(5, 10),
                        repeat: -1,
                        yoyo: true,
                        ease: "power1.inOut"
                    });

                    animations.push(rotationAnim, movementAnim);
                });

                // Cleanup function
                return function cleanup() {
                    animations.forEach(function(anim) {
                        anim.kill();
                    });
                };
            } else {
                console.error("GSAP is not loaded correctly.");
            }
        }

        var cleanupFn = startWhirlwindTextAnimation();

        // Optional: Cleanup when leaving the page
        window.addEventListener(beforeunload, function() {
            if (cleanupFn) cleanupFn();
        });
    });
    </script>';
    return $output;
}
add_shortcode('whirlwind_text', 'midjourney_whirlwind_text_shortcode');
